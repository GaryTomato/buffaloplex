kettu.config = {
  reloadInterval: 2000,
  storeName: 'data'
};