kettu.store = new Sammy.Store({
  name: kettu.config.storeName,
  type: ['local', 'cookie']
});